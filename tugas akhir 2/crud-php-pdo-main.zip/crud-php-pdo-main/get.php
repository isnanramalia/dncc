<?php

echo $_POST['nama'];
